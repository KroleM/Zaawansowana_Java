package Program_PD3;


public class Start {

	public static void main(String[] args) 
	{
		new Kalkulator();
		//new ZegarThread(kalkulator).start();

	}

}
