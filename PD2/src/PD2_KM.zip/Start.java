
public class Start {

	public static void main(String[] args) 
	{
		new Kalkulator();
		//new Tlumacz();
		//new T�umacz2();
	}
}
