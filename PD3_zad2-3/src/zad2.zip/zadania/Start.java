package zadania;

public class Start {

	public static void main(String[] args) 
	{
		//PD3: zadanie 2
		new Minutnik();

	}

}
