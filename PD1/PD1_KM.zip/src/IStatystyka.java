//Zadanie 2.3
public interface IStatystyka 
{
	public double suma();
	public double srednia();
	public double max();
}
