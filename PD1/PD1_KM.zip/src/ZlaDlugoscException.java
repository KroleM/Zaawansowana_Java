
public class ZlaDlugoscException extends Exception 
{
	public ZlaDlugoscException()
	{
		super("Niezgodno�� wymiar�w dw�ch dodawanych wektor�w.");	
	}
}
